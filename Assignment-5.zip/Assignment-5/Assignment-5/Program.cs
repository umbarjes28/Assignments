﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Assignment_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> Ministers;
            Ministers = new Dictionary<int, string>();
            Ministers.Add(1998, "Atal Bihari Vajpayee");
            Ministers.Add(2014, "Narendra Modi");
            Ministers.Add(2004, "Manmohan Singh");
           
            

            Console.WriteLine("=====================================");
            foreach(KeyValuePair<int, string> minister in Ministers)
            {
                Console.WriteLine(minister.Key + "-" + minister.Value);
            }
            Console.WriteLine("=====================================");
            Console.WriteLine("The Prime minister of 2004");
            Console.WriteLine(Ministers[2004]);

            Console.WriteLine("=====================================");
            Console.WriteLine("Enter Current Prime minister : ");
            string Name= Console.ReadLine();
            Ministers.Add(DateTime.Now.Year, Name);
            Console.WriteLine("=====================================");
            foreach (KeyValuePair<int, string> minister in Ministers)
            {
                Console.WriteLine(minister.Key + "-" + minister.Value);
            }
            Console.WriteLine("=====================================");
            Console.WriteLine("Ascending List:");
            var list = Ministers.Keys.ToList();
            list.Sort();

            foreach (var key in list)
            {
                Console.WriteLine("{0}: {1}", key, Ministers[key]);
            }

        }
    }
}
