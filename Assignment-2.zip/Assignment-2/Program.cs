﻿using System;

namespace Assignment_2
{
    public abstract class Employee
    {
        public int Id { get; }
        public string Name { get; }
        public string Designation { get; }
        public int Experience { get; }
        public int Annual_sal { get; }
        public DateTime Joining_date { get; }

        public abstract void Calculate_Sal(int experience);
    }

    public class Developer : Employee
    {
       public int DevId;
        string DevName;
        string DevDesignation;
        int DevExp;
        string DevJoinigDate;
        public Developer(int Id, string Name, string Designation, string Joining_date, int Experience)
        {
            DevId = Id;
            DevName = Name;
            DevDesignation = Designation;
            DevExp = Experience;
            DevJoinigDate = Joining_date;
        }
        public override void Calculate_Sal(int experience)
        {

            int Salary = (experience * 1000) * 12;
            Console.WriteLine("Your Annual Basic Salary : " + Salary);
        }
    }

    class Hr : Employee
    {
        public int HId;
        string HName;
        string HDesignation;
        int HExp;
        string HJoinigDate;
        public Hr(int Id, string Name, string Designation, string Joining_date, int Experience)
        {
            HId = Id;
            HName = Name;
            HDesignation = Designation;
            HExp = Experience;
            HJoinigDate = Joining_date;
        }
        public override void Calculate_Sal(int Experience)
        {
            int Salary = (2000 * Experience)*12;
            Console.WriteLine("Your Annual Basic Salary : "+ Salary);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Please Enter Developer Details:");
            Console.WriteLine("Enter Id : ");
            int Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name : ");
            string Name = Console.ReadLine();
            Console.WriteLine("Enter Designation : ");
            string Designation = Console.ReadLine();
            Console.WriteLine("Enter Joining Date : ");
            string Joining_date = Console.ReadLine();
            Console.WriteLine("Enter Experience : ");
            int Exp = Convert.ToInt32(Console.ReadLine());
            Developer Dev = new Developer(Id,Name,Designation,Joining_date,Exp);
            Dev.Calculate_Sal(Exp);

            Console.WriteLine("Please Enter HR Details:");
            Console.WriteLine("Enter Id : ");
            int HId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name : ");
            string HName = Console.ReadLine();
            Console.WriteLine("Enter Designation : ");
            string HDesignation = Console.ReadLine();
            Console.WriteLine("Enter Joining Date : ");
            string HJoining_date = Console.ReadLine();
            Console.WriteLine("Enter Experience : ");
            int HExp = Convert.ToInt32(Console.ReadLine());
            Hr hr = new Hr(HId, HName, HDesignation, HJoining_date, HExp);
            hr.Calculate_Sal(HExp);
        }
    }
}
