﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections;

public class Program
{
    public IList employeeList;
    public IList salaryList;

    public Program()
    {
        employeeList = new List<Employee>() {
            new Employee(){ EmployeeID = 1, EmployeeFirstName = "Rajiv", EmployeeLastName = "Desai", Age = 49},
            new Employee(){ EmployeeID = 2, EmployeeFirstName = "Karan", EmployeeLastName = "Patel", Age = 32},
            new Employee(){ EmployeeID = 3, EmployeeFirstName = "Sujit", EmployeeLastName = "Dixit", Age = 28},
            new Employee(){ EmployeeID = 4, EmployeeFirstName = "Mahendra", EmployeeLastName = "Suri", Age = 26},
            new Employee(){ EmployeeID = 5, EmployeeFirstName = "Divya", EmployeeLastName = "Das", Age = 20},
            new Employee(){ EmployeeID = 6, EmployeeFirstName = "Ridhi", EmployeeLastName = "Shah", Age = 60},
            new Employee(){ EmployeeID = 7, EmployeeFirstName = "Dimple", EmployeeLastName = "Bhatt", Age = 53}
        };

        salaryList = new List<Salary>() {
            new Salary(){ EmployeeID = 1, Amount = 1000, Type = SalaryType.Monthly},
            new Salary(){ EmployeeID = 1, Amount = 500, Type = SalaryType.Performance},
            new Salary(){ EmployeeID = 1, Amount = 100, Type = SalaryType.Bonus},
            new Salary(){ EmployeeID = 2, Amount = 3000, Type = SalaryType.Monthly},
            new Salary(){ EmployeeID = 2, Amount = 1000, Type = SalaryType.Bonus},
            new Salary(){ EmployeeID = 3, Amount = 1500, Type = SalaryType.Monthly},
            new Salary(){ EmployeeID = 4, Amount = 2100, Type = SalaryType.Monthly},
            new Salary(){ EmployeeID = 5, Amount = 2800, Type = SalaryType.Monthly},
            new Salary(){ EmployeeID = 5, Amount = 600, Type = SalaryType.Performance},
            new Salary(){ EmployeeID = 5, Amount = 500, Type = SalaryType.Bonus},
            new Salary(){ EmployeeID = 6, Amount = 3000, Type = SalaryType.Monthly},
            new Salary(){ EmployeeID = 6, Amount = 400, Type = SalaryType.Performance},
            new Salary(){ EmployeeID = 7, Amount = 4700, Type = SalaryType.Monthly}
        };
    }

    public static void Main()
    {
        Program program = new Program();

        program.Task1();

        program.Task2();

        program.Task3();
    }

    public void Task1()
    {
        var query = employeeList.Cast<Employee>().GroupJoin(salaryList.Cast<Salary>(),
                                                        e => e.EmployeeID,
                                                        s => s.EmployeeID,

                                                        (e, s) => new
                                                        {
                                                            e.EmployeeID,
                                                            e.EmployeeFirstName,
                                                            e.EmployeeLastName,
                                                            e.Age,

                                                            avg = from sal in s
                                                                  group sal by e.EmployeeID into g
                                                                  select new
                                                                  {
                                                                      Team = g.Key,
                                                                      Sum = g.Sum(x => x.Amount)
                                                                  }
                                                        })
                      .OrderBy(s =>s.EmployeeFirstName);
        Console.WriteLine("================== Task 1 ===========================");
        foreach(var val in query)
        {
            Console.WriteLine($"{val.EmployeeFirstName} {val.EmployeeLastName} : ");
            foreach(var amt in val.avg)
            {
                Console.WriteLine($"{amt.Sum} ");
            }
        }
    }

    public void Task2()
    {
        var query1 = employeeList.Cast<Employee>().Join(salaryList.Cast<Salary>(),
                                                        e => e.EmployeeID,
                                                        s => s.EmployeeID,
                                                        (e, s) => new
                                                        {
                                                            s.EmployeeID,
                                                            e.EmployeeFirstName,
                                                            e.EmployeeLastName,
                                                            e.Age,
                                                            s.Amount,
                                                            s.Type
                                                        })
                      .Where(s =>s.Type == SalaryType.Monthly)
                      .OrderByDescending(e => e.Age)
                      .GroupBy(s => s.EmployeeID)
                      .Skip(1)
                      .First();
                     

       
        Console.WriteLine("================== Task 2 ===========================");
        foreach(var val in query1)
        {
            Console.WriteLine($"Name : {val.EmployeeFirstName} {val.EmployeeLastName} \n Age : {val.Age} \n Salary : {val.Amount}  Salary Type : {val.Type}");
        }
            
        
    }

    public void Task3()
    {
        var query1 = employeeList.Cast<Employee>().GroupJoin(salaryList.Cast<Salary>(),
                                                        e => e.EmployeeID,
                                                        s => s.EmployeeID,

                                                        (e, s) => new
                                                        {
                                                            e.EmployeeID,
                                                            e.EmployeeFirstName,
                                                            e.EmployeeLastName,
                                                            e.Age,
                                                            
                                                            avg = from sal in s
                                                                  group sal by e.EmployeeID into g
                                                                  select new
                                                                  {
                                                                      Team = g.Key,
                                                                      AverageScore = g.Average(x => x.Amount)
                                                                  }
                                                        })
                      .Where(e => e.Age > 30);
          
        Console.WriteLine("================== Task 3 ===========================");
        foreach (var val in query1)
        {
            Console.WriteLine($"Id : {val.EmployeeID} ");
            
                Console.WriteLine($" Name : {val.EmployeeFirstName} {val.EmployeeLastName} \n Age : {val.Age} ");
            foreach (var avg in val.avg)
            {
                Console.WriteLine($"Mean salry : {avg.AverageScore}");
            }
           Console.WriteLine("_____________________");

        }
    }
}

public enum SalaryType
{
    Monthly,
    Performance,
    Bonus
}

public class Employee
{
    public int EmployeeID { get; set; }
    public string EmployeeFirstName { get; set; }
    public string EmployeeLastName { get; set; }
    public int Age { get; set; }
}

public class Salary
{
    public int EmployeeID { get; set; }
    public int Amount { get; set; }
    public SalaryType Type { get; set; }
}