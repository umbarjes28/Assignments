﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Arrays
{
    public class product
    {
        public string Name;
        public string Price;
        public int Quantity;
        public string Type;
    }
    class Program
    {
        static void Main(string[] args)
        {
            var products = new List<product>();
            products.Add(new product() { Name="lettuce", Price="10.5 RS", Quantity=50, Type="Leafy green" });
            products.Add(new product() { Name = "cabbage", Price = "20 RS", Quantity = 100, Type = "Cruciferous" });
            products.Add(new product() { Name = "pumpkin", Price = "30 RS", Quantity = 30, Type = "Marrow" });
            products.Add(new product() { Name = "cauliflower", Price = "10 RS", Quantity = 25, Type = "Cruciferous" });
            products.Add(new product() { Name = "zucchini", Price = "20.5 RS", Quantity = 50, Type = "Marrow" });
            products.Add(new product() { Name = "yam", Price = "30 RS", Quantity = 50, Type = "Root" });
            products.Add(new product() { Name = "spinach", Price = "10 RS", Quantity = 100, Type = "Leafy green" });
            products.Add(new product() { Name = "broccoli", Price = "20.2 RS", Quantity = 75, Type = "Cruciferous" });
            products.Add(new product() { Name = "garlic", Price = "30 RS", Quantity = 20, Type = "Leafy green" });
            products.Add(new product() { Name = "silverbeet", Price = "10 RS", Quantity = 50, Type = "Marrow" });

            Console.WriteLine("Do you want to add products: (Yes/No)");
            var Answer = Console.ReadLine();
            if(Answer == "Yes" || Answer == "yes")
            {
                Console.WriteLine("How many product do you wants to add : (numbers)");
                bool NoOfProductsCheckNumberFormat = Int32.TryParse(Console.ReadLine(), out int NoOfProducts);
                if(NoOfProductsCheckNumberFormat == true)
                {
                    for(int i =0; i< NoOfProducts; i++)
                    {
                        Console.WriteLine("Enter Product Name : ");
                        string Pname = Console.ReadLine();
                        Console.WriteLine("Enter Product Price : ");
                        string Pprice=Console.ReadLine();
                            Console.WriteLine("Enter Product Quantity : ");
                            bool PquantitycheCkNumberFormat = Int32.TryParse(Console.ReadLine(), out int pquantity);
                            if(PquantitycheCkNumberFormat == true)
                            {
                                Console.WriteLine("Enter product type : ");
                                string Ptype = Console.ReadLine();
                                products.Add(new product() { Name = Pname, Price = Pprice, Quantity = pquantity, Type = Ptype });
                                Console.WriteLine("Your Product Added Successfully !");
                            }
                            else
                            {
                                Console.WriteLine("Please Enter integer quantity!");
                                break;
                            }

                    }
                }
                else
                {
                    Console.WriteLine("Please enter interger value!");
            
                }

                Console.WriteLine("Total No. Of products = {0}", products.Count);
                Console.WriteLine("============================================================================ ");
                Console.WriteLine("Below list of Leafy green products : ");
                for (int i = 0; i < products.Count; i++)
                {
                    if(products[i].Type == "Leafy green")
                    {
                        Console.WriteLine(products[i].Name);
                    }
                    
                }
                Console.WriteLine("============================================================================ ");
                Console.WriteLine(" Garlic product was sold outs! ");
                for (int i = 0; i < products.Count; i++)
                {
                    if (products[i].Name == "garlic")
                    {
                        products.RemoveAt(i);
                    }

                }
                Console.WriteLine("============================================================================ ");
                Console.WriteLine(" Now Available Products : ");
                Console.WriteLine("Name |  Price |  Quantity |  Type   ");
                for (int i = 0; i < products.Count; i++)
                {
                        Console.WriteLine(products[i].Name + " | " + products[i].Price + " | " + products[i].Quantity + " | " + products[i].Type);
                }

                Console.WriteLine("============================================================================ ");
                Console.WriteLine("Added 50 Quantity of Cabbages ");
                for (int i = 0; i < products.Count; i++)
                {
                    if(products[i].Name == "cabbage")
                    {
                        products[i].Quantity = products[i].Quantity + 50;
                        Console.WriteLine("Available Quantity of cabbages in inventory = {0}", products[i].Quantity);
                    }
                }

                Console.WriteLine("============================================================================ ");
                Console.WriteLine("Do you want to purse products : (Yes/No)");
                string Respond = Console.ReadLine();
                double TotalPrice = 0;
                if (Respond == "Yes" || Respond == "yes")
                {
                    string AddProduct = "Y";
                    do
                    {
                        Console.WriteLine("Enter Product Name : ");
                        string ProductName = Console.ReadLine().ToLower();
                        Console.WriteLine("Enter Product Quantity : ");
                        bool CheckQuantityFormat = Int32.TryParse(Console.ReadLine(), out int ProductQuantity);
                        if (CheckQuantityFormat == true)
                        {
                            var productQuery = from p in products
                                               where p.Name.Contains(ProductName)
                                               select p.Price;
                            foreach (var price in productQuery)
                            {
                                int index = price.IndexOf("RS");
                                string result = price.Remove(index);
                                double amt = Convert.ToDouble(result);
                                TotalPrice = TotalPrice + (amt * ProductQuantity);

                            }
                        }
                        else
                        {
                            Console.WriteLine("Please Enter Valid Quantity!");
                        }
                        Console.WriteLine("Do you want to add Another Product : (Y/N)");
                        AddProduct = Console.ReadLine();
                        if(AddProduct != "Y")
                        {
                            break;
                        }
                    } while (AddProduct == "Y" || AddProduct == "y");

                    Console.WriteLine("============================================================================ ");
                    Console.WriteLine("Total Amount : {0}",TotalPrice);

                }


            }
            
            
            
        }
    }
}
