﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace event_programming
{
    //This is Subscriber Class
    class Program
    {
        static void Main(string[] args)
        {
            //Get and displaye employee info
            Console.WriteLine("Enter Id: ");
            int Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name : ");
            string Name = Console.ReadLine();
            Console.WriteLine("Enter Department : ");
            string Dept = Console.ReadLine();
            Employee EmpObj = new Employee(Id, Name, Dept);
            EmpObj.GetId();
            EmpObj.GetName();
            EmpObj.GetDept();

            // event and delegate call
            Employee Emp = new Employee(Id,Name,Dept);
            Emp.ev_OddNumber += new Employee.dg_OddNumber(EventMessage);
            Emp.GetName();

            //Update overloading methods
            Console.WriteLine("You Want to Update Id & Name of employee : (Yes/No)");
            string Input = Console.ReadLine();
            if (Input == "Yes")
            {
                Console.WriteLine("Enter Id : ");
                int IdUpdate = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Name : ");
                string NameUpdate = Console.ReadLine();
                Emp.Update(IdUpdate,NameUpdate);
                Console.WriteLine("Id Updated Successfully");
            }

            Console.WriteLine("You Want to Update Department of employee : (Yes/No)");
            string InputDepartment = Console.ReadLine();
            if (InputDepartment == "Yes")
            {
                Console.WriteLine("Enter Department : ");
                string DeptUpdate = Console.ReadLine();
                Emp.Update(DeptUpdate);
                Console.WriteLine("Department Updated Successfully");
            }
            Console.WriteLine("You Want to Update Id of employee : (Yes/No)");
            string InputId = Console.ReadLine();
            if(InputId == "Yes")
            {
                Console.WriteLine("Enter Id : ");
                Emp.Update(Convert.ToInt32(Console.ReadLine()));
                Console.WriteLine("Id Updated Successfully");
            }
            Emp.GetId();
            Emp.GetName();
            Emp.GetDept();

        }
        //Delegates calls this method when event raised.  
        public static void EventMessage()
        {
            Console.WriteLine("********Event Executed : This is Odd Number**********");
        }
    }
    //This is Publisher Class
    class Employee
    {
        public delegate void dg_OddNumber(); //Declared Delegate     
        public event dg_OddNumber ev_OddNumber; //Declared Events
        private int Id;
        private string Name;
        private string DeptName;
        public Employee(int id, string name, string deptname)
        {
            Id = id;
            Name = name;
            DeptName = deptname;
        } 
        public void GetName()
        {
            Console.WriteLine("Employee Name : " + Name);
        }
        public void GetId()
        {
            Console.WriteLine("Employee Id : "+ Id);
        }
        public void GetDept()
        {
            Console.WriteLine("Employee Department Name : "+DeptName);
        }

        public void Update(int id)
        {
            Id = id;
        }

        public void Update(int id,string name)
        {
            Id = id;
            Name = name;
        }

        public void Update(string deptname)
        {
            DeptName = deptname;
        }
    }
}