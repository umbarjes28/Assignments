﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Assignment_4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> Word = new List<string>();
            Word.Add("boat");
            Word.Add("house");
            Word.Add("cat");
            Word.Add("river");
            Word.Add("cupboard");

            Console.WriteLine("List of Array :");
            foreach(string Words in Word)
            {
                Console.WriteLine(Words);
            }
            Console.WriteLine("================================================");
            Console.WriteLine("List of Plurals :");
            foreach (string Words in Word)
            {
                Console.WriteLine(Words+"s");
            }

            Console.WriteLine("================================================");
            Console.WriteLine("Enter one word in List :");
            Word.Add(Console.ReadLine());
            foreach (string Words in Word)
            {
                Console.WriteLine(Words);
            }
            Console.WriteLine("================================================");
            Console.WriteLine("list of words thats Length 7 or more than 7");
            var query=  from words in Word
                        where words.Length >= 7
                        select words;
            foreach(var data in query)
            {
                Console.WriteLine(data);
            }
            Console.WriteLine("================================================");
            Console.WriteLine("Third position Word : {0} ", Word.ElementAt(2));

            Word.Sort();
            Console.WriteLine("================================================");
            Console.WriteLine("Asending order words :");
            foreach (string Words in Word)
            {
                Console.WriteLine(Words);
            }

            Word.Reverse();
            Console.WriteLine("================================================");
            Console.WriteLine("Reverse List :");
            foreach (string Words in Word)
            {
                Console.WriteLine(Words);
            }

        }
    }
}
